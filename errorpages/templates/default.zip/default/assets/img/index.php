<?php 
//Silence is a true friend who never betrays.
?>